import { Component, OnInit } from '@angular/core';
import {ServicesService} from '../services.service';

@Component({
  selector: 'app-link',
  templateUrl: './link.component.html',
  styleUrls: ['./link.component.css']
})
export class LinkComponent implements OnInit {
    model:any ={};
  constructor(private servicesService:ServicesService) { }
  
   pasteUrl(e){

  // this.ServicesService.createLink();
   // this.model.link=e;
  //  this.servicesService.createLink(e);


}
    
  ngOnInit() {
	   
  }

}
