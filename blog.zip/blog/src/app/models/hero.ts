export class Hero {
	name :  string;
	alterEgo:  string;
	power :  string;
	
	
	
}