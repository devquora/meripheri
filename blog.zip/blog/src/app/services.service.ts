import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from "rxjs/Rx";
import { Hero } from "./models/hero";
import { Taxi } from "./models/taxi";




@Injectable()

/*
export class ServicesService {

  constructor(private http : Http) { }
      
	  
	 
	 
  public createHero(hero : Hero) {
	  
	  console.log("post data on server........!");
	  console.log(hero);
	   
   	return this.http.post('http://localhost:8081/save-hero',hero).map((response: Response) => response.json())
			.catch((err) => {
				  return Observable.throw(err)
			  })
			  
			  
	}
		
}
*/  
/*
export class ServicesService {

  constructor(private http : Http) { }
  
	  
	 
	 
  public createLink(link):any {
	  
	 
	  console.log(link);
	   
   	return this.http.post('http://localhost:8081/save' ,link).map((response: Response) => response.json())
			.catch((err) => {
				  return Observable.throw(err)
			  })
			  
			  
	}
	
	
}

*/

export class ServicesService {

  constructor(private http : Http) { }
      
  public createTaxi(taxi : Taxi) {
	  
	  console.log("post data on server........!");
	   console.log(taxi);
	   
   	return this.http.post('http://localhost:8081/save-hero',taxi).map((response: Response) => response.json())
			.catch((err) => {
				  return Observable.throw(err)
			  })
			  
	}
	
	
}  