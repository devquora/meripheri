'use strict';
var mongoose =  require('mongoose');
var GetQuestionSchema = new mongoose.Schema({
	
		
		//type : Array,
		//question :[],
		
		//question : { type : Array , "default" : [] },
		
		question: {
           type: Array,
      question : {
        type: String
      }
    },
      
	
	status : {
		type : String,
		trim : true,
		default: "active"
	}
	
});

var GetQuestion = mongoose.model('GetQuestion',GetQuestionSchema);
module.exports = GetQuestion;
	
	