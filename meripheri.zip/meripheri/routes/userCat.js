'use strict';
module.exports = function(app,connection) {

var UserCat = require('../controller/UserCatController');
 const validate = require('express-validation')
 const userCatValidations  = require('../validations/userCat');
 
 
       app.route('/seller')
	      .post(userCatValidations.userCat, UserCat.save);
		  
	   app.route('/seller')
	      .put(userCatValidations.userCat, UserCat.update);

       app.route('/seller/:id')
	      .get( UserCat.listAll);		  
		  
		 
		  
		  
}