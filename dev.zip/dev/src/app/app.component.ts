import { Component } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
	emailValidation = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  
  passwordValidation = new FormControl('', [
    Validators.required
  
  ]);

}
